const path = require('path');
const fs = require('fs-extra');
const express = require('express');
const axios = require('axios');
const AdmZip = require('adm-zip');

const MODRINTH_UA = 'CloudSpeak/MC-Panel/2.0.0 (henvei@cloudspeak.com)';

function applyGithubProxy(url) {
    if (!url || typeof url !== 'string') return url;
    const config = this._getConfig ? this._getConfig() : {};
    const githubProxy = config.githubProxy || '';
    if (githubProxy && (url.includes('github.com') || url.includes('githubusercontent.com'))) {
        let proxy = githubProxy;
        if (!proxy.endsWith('/')) proxy += '/';
        if (url.startsWith(proxy)) return url;
        return proxy + url;
    }
    return url;
}

// 轻量限容 Map，防止无限增长
class BoundedMap extends Map {
    constructor(maxSize = 200) {
        super();
        this.maxSize = maxSize;
    }
    set(key, value) {
        if (this.size >= this.maxSize && !this.has(key)) {
            const firstKey = this.keys().next().value;
            this.delete(firstKey);
        }
        return super.set(key, value);
    }
}

// 实例已安装资源内存缓存 (避免频繁解压 jar 导致性能问题)
const installedCache = new BoundedMap(60);
// 物理 jar 包轻量元数据缓存 (key: fullPath:mtimeMs:size, 避免对未修改 jar 重复 new AdmZip 导致内存激增)
const jarMetaCache = new BoundedMap(500);

async function scanInstanceInstalledResources(instanceDir) {
    if (!instanceDir || !fs.existsSync(instanceDir)) {
        return { projectIds: [], slugs: [], modIds: [], names: [], filenames: [] };
    }

    const cached = installedCache.get(instanceDir);
    const now = Date.now();
    if (cached && (now - cached.timestamp < 10000)) {
        return cached.data;
    }

    const projectIds = new Set();
    const slugs = new Set();
    const modIds = new Set();
    const names = new Set();
    const filenames = new Set();

    // 1. 读取由面板记录的已安装资源表 (.mc-panel/installed-resources.json)
    const recordFile = path.join(instanceDir, '.mc-panel', 'installed-resources.json');
    if (fs.existsSync(recordFile)) {
        try {
            const data = await fs.readJson(recordFile);
            if (data && data.projects) {
                for (const p of Object.values(data.projects)) {
                    if (p.id) projectIds.add(String(p.id));
                    if (p.projectId) projectIds.add(String(p.projectId));
                    if (p.slug) slugs.add(String(p.slug).toLowerCase());
                    if (p.title) names.add(String(p.title).toLowerCase());
                    if (p.filename) filenames.add(String(p.filename).toLowerCase());
                }
            }
        } catch (_) {}
    }

    // 2. 扫描物理目录: mods, plugins, world/datapacks, resourcepacks
    const scanDirs = [
        { dir: path.join(instanceDir, 'mods'), isJar: true },
        { dir: path.join(instanceDir, 'plugins'), isJar: true },
        { dir: path.join(instanceDir, 'world', 'datapacks'), isJar: false },
        { dir: path.join(instanceDir, 'resourcepacks'), isJar: false }
    ];

    for (const { dir, isJar } of scanDirs) {
        if (!fs.existsSync(dir)) continue;
        try {
            const files = await fs.readdir(dir);
            for (const file of files) {
                if (file.startsWith('.')) continue;
                filenames.add(file.toLowerCase());

                // 清理扩展名 (.disabled, .jar, .zip)
                const cleanBase = file.replace(/\.(disabled|jar|zip)$/i, '').replace(/\.(jar|zip)$/i, '').toLowerCase();
                // 常见模式：voicechat-fabric-1.20.1-2.5.0 -> voicechat
                const slugCandidate = cleanBase.split(/[-_]\d+/)[0];
                if (slugCandidate) {
                    slugs.add(slugCandidate);
                    modIds.add(slugCandidate);
                }

                if (isJar && (file.endsWith('.jar') || file.endsWith('.jar.disabled'))) {
                    const fullPath = path.join(dir, file);
                    try {
                        const stat = await fs.stat(fullPath);
                        const cacheKey = `${fullPath}:${stat.mtimeMs}:${stat.size}`;
                        let jarMeta = jarMetaCache.get(cacheKey);

                        if (!jarMeta) {
                            jarMeta = { modIds: [], names: [], slugs: [] };
                            try {
                                const zip = new AdmZip(fullPath);
                                const zipEntries = zip.getEntries();
                                for (const entry of zipEntries) {
                                    const en = entry.entryName.toLowerCase();
                                    if (en === 'fabric.mod.json' || en === 'quilt.mod.json') {
                                        try {
                                            const json = JSON.parse(entry.getData().toString('utf8'));
                                            if (json.id) jarMeta.modIds.push(String(json.id).toLowerCase());
                                            if (json.name) jarMeta.names.push(String(json.name).toLowerCase());
                                        } catch (_) {}
                                    } else if (en === 'plugin.yml') {
                                        try {
                                            const text = entry.getData().toString('utf8');
                                            const match = text.match(/^name:\s*['"]?([^'"\r\n]+)['"]?/m);
                                            if (match && match[1]) {
                                                const pName = match[1].trim().toLowerCase();
                                                jarMeta.names.push(pName);
                                                jarMeta.slugs.push(pName);
                                                jarMeta.modIds.push(pName);
                                            }
                                        } catch (_) {}
                                    }
                                }
                            } catch (_) {}
                            jarMetaCache.set(cacheKey, jarMeta);
                        }

                        for (const id of jarMeta.modIds) modIds.add(id);
                        for (const name of jarMeta.names) names.add(name);
                        for (const slug of jarMeta.slugs) slugs.add(slug);
                    } catch (_) {}
                }
            }
        } catch (_) {}
    }

    const result = {
        projectIds: Array.from(projectIds),
        slugs: Array.from(slugs),
        modIds: Array.from(modIds),
        names: Array.from(names),
        filenames: Array.from(filenames)
    };

    installedCache.set(instanceDir, { timestamp: now, data: result });
    return result;
}

async function recordInstalledResource(instanceDir, info) {
    if (!instanceDir || !info) return;
    try {
        const pDir = path.join(instanceDir, '.mc-panel');
        await fs.ensureDir(pDir);
        const recordFile = path.join(pDir, 'installed-resources.json');
        let data = { projects: {} };
        if (fs.existsSync(recordFile)) {
            try {
                data = await fs.readJson(recordFile);
                if (!data.projects) data.projects = {};
            } catch (_) {}
        }
        const key = info.projectId || info.slug || info.filename;
        data.projects[key] = {
            id: info.projectId || null,
            projectId: info.projectId || null,
            slug: info.slug || null,
            title: info.title || info.filename,
            filename: info.filename,
            versionId: info.versionId || null,
            type: info.type || 'mod',
            installedAt: Date.now()
        };
        await fs.writeJson(recordFile, data, { spaces: 2 });
        installedCache.delete(instanceDir);
    } catch (_) {}
}

module.exports = (api) => {
    const _getConfig = () => api.getConfig() || {};
    const proxyCtx = { _getConfig };
    const applyProxy = applyGithubProxy.bind(proxyCtx);

    const router = express.Router();

    // GET /search - Proxy search to Modrinth API
    router.get('/search', async (req, res) => {
        const { q, facets, offset, limit, index } = req.query;
        try {
            const params = { query: q, limit: limit || 20, offset: offset || 0 };
            if (facets) params.facets = facets;
            if (index) params.index = index;
            const response = await axios.get('https://api.modrinth.com/v2/search', {
                params,
                headers: { 'User-Agent': MODRINTH_UA }
            });
            res.json(response.data);
        } catch (e) {
            api.logger.error('[Modrinth Search Error]', e.message);
            res.status(500).json({ error: e.message });
        }
    });

    // GET /versions - Proxy game versions from Modrinth API
    router.get('/versions', async (req, res) => {
        try {
            const response = await axios.get('https://api.modrinth.com/v2/tag/game_version', {
                headers: { 'User-Agent': MODRINTH_UA }
            });
            res.json(response.data);
        } catch (e) {
            api.logger.error('[Modrinth Versions Error]', e.message);
            res.status(500).json({ error: e.message });
        }
    });

    // GET /project/:id - Proxy project + versions from Modrinth API
    router.get('/project/:id', async (req, res) => {
        try {
            const [project, versions] = await Promise.all([
                axios.get(`https://api.modrinth.com/v2/project/${req.params.id}`, {
                    headers: { 'User-Agent': MODRINTH_UA }
                }),
                axios.get(`https://api.modrinth.com/v2/project/${req.params.id}/version`, {
                    headers: { 'User-Agent': MODRINTH_UA }
                })
            ]);
            res.json({ project: project.data, versions: versions.data });
        } catch (e) {
            api.logger.error('[Modrinth Project Error]', e.message);
            res.status(500).json({ error: e.message });
        }
    });

    // GET /installed - 获取当前实例已安装资源标识集合 (跨模组、插件、数据包、资源包)
    router.get('/installed', async (req, res) => {
        const instanceId = req.query.instanceId || api.getActiveInstanceId();
        const instanceDir = api.getInstanceDir(instanceId);
        try {
            const installedData = await scanInstanceInstalledResources(instanceDir);
            res.json(installedData);
        } catch (e) {
            api.logger.error('[Modrinth Installed Scan Error]', e.message);
            res.status(500).json({ error: e.message });
        }
    });

    // POST /resolve-dependencies - 递归解析必要前置依赖，防死循环与自动过滤已安装项
    router.post('/resolve-dependencies', async (req, res) => {
        const { versionId, projectId, gameVersion, loader, instanceId } = req.body;
        if (!versionId) return res.status(400).json({ error: 'versionId required' });

        const instId = instanceId || api.getActiveInstanceId();
        const instanceDir = api.getInstanceDir(instId);
        const installedData = await scanInstanceInstalledResources(instanceDir);

        const isInstalled = (pid, slug, title) => {
            if (pid && installedData.projectIds.includes(pid)) return true;
            if (slug) {
                const s = slug.toLowerCase();
                if (installedData.slugs.includes(s) || installedData.modIds.includes(s)) return true;
            }
            if (title) {
                const t = title.toLowerCase();
                if (installedData.names.includes(t) || installedData.slugs.includes(t)) return true;
            }
            return false;
        };

        const visitedProjects = new Set();
        const visitedVersions = new Set();
        const requiredDeps = [];
        const skippedDeps = [];
        const projectCache = new Map();

        // 初始将目标项目加入 visited，防止环形依赖回目标项目自身
        if (projectId) {
            visitedProjects.add(projectId);
        }

        async function getProjectInfo(pId) {
            if (projectCache.has(pId)) return projectCache.get(pId);
            try {
                const pRes = await axios.get(`https://api.modrinth.com/v2/project/${pId}`, {
                    headers: { 'User-Agent': MODRINTH_UA },
                    timeout: 6000
                });
                projectCache.set(pId, pRes.data);
                return pRes.data;
            } catch (_) {
                return null;
            }
        }

        async function resolveVersion(vId, depth = 0) {
            // 最大递归深度限制 (防极端死循环)
            if (depth > 8) return;
            if (visitedVersions.has(vId)) return;
            visitedVersions.add(vId);

            let verData = null;
            try {
                const vRes = await axios.get(`https://api.modrinth.com/v2/version/${vId}`, {
                    headers: { 'User-Agent': MODRINTH_UA },
                    timeout: 6000
                });
                verData = vRes.data;
            } catch (e) {
                api.logger.warn(`[Modrinth Dependencies] 获取版本 ${vId} 失败:`, e.message);
                return;
            }

            if (!verData || !Array.isArray(verData.dependencies) || verData.dependencies.length === 0) {
                return;
            }

            for (const dep of verData.dependencies) {
                // 只解析必要前置 (required)，非必要 (optional / incompatible) 忽略
                if (dep.dependency_type !== 'required') continue;

                let depProjectId = dep.project_id;
                let depVersionId = dep.version_id;

                if (!depProjectId && depVersionId) {
                    try {
                        const dvRes = await axios.get(`https://api.modrinth.com/v2/version/${depVersionId}`, {
                            headers: { 'User-Agent': MODRINTH_UA },
                            timeout: 5000
                        });
                        if (dvRes.data) {
                            depProjectId = dvRes.data.project_id;
                        }
                    } catch (_) {}
                }

                if (!depProjectId) continue;

                // 防死循环与重复解析：一个 project 只处理一次
                if (visitedProjects.has(depProjectId)) continue;
                visitedProjects.add(depProjectId);

                const proj = await getProjectInfo(depProjectId);
                if (!proj) continue;

                // 检查当前实例是否已经安装
                if (isInstalled(depProjectId, proj.slug, proj.title)) {
                    skippedDeps.push({
                        projectId: depProjectId,
                        title: proj.title,
                        slug: proj.slug,
                        icon_url: proj.icon_url,
                        reason: '已安装在当前实例'
                    });
                    continue;
                }

                // 尚未安装：寻找该依赖匹配当前环境的最佳版本
                let matchedVer = null;
                if (depVersionId) {
                    try {
                        const dvRes = await axios.get(`https://api.modrinth.com/v2/version/${depVersionId}`, {
                            headers: { 'User-Agent': MODRINTH_UA },
                            timeout: 6000
                        });
                        matchedVer = dvRes.data;
                    } catch (_) {}
                }

                if (!matchedVer) {
                    try {
                        const queryParams = {};
                        if (loader) queryParams.loaders = JSON.stringify([loader]);
                        if (gameVersion) queryParams.game_versions = JSON.stringify([gameVersion]);

                        const pvRes = await axios.get(`https://api.modrinth.com/v2/project/${depProjectId}/version`, {
                            params: queryParams,
                            headers: { 'User-Agent': MODRINTH_UA },
                            timeout: 6000
                        });

                        let vList = pvRes.data || [];
                        if (vList.length === 0 && (queryParams.loaders || queryParams.game_versions)) {
                            // 若带 loader + gameVersion 没匹配到，放宽条件查询该 project 的所有版本
                            const fallbackRes = await axios.get(`https://api.modrinth.com/v2/project/${depProjectId}/version`, {
                                headers: { 'User-Agent': MODRINTH_UA },
                                timeout: 6000
                            });
                            vList = fallbackRes.data || [];
                        }

                        if (vList.length > 0) {
                            // 优先选 release 版本
                            matchedVer = vList.find(v => v.version_type === 'release') || vList[0];
                        }
                    } catch (e) {
                        api.logger.warn(`[Modrinth Dependencies] 查询依赖 ${proj.title} 匹配版本失败:`, e.message);
                    }
                }

                if (matchedVer && Array.isArray(matchedVer.files) && matchedVer.files.length > 0) {
                    // 先递归解析该依赖自身的前置依赖 (拓扑排序：深层前置先就绪)
                    await resolveVersion(matchedVer.id, depth + 1);

                    const primaryFile = matchedVer.files.find(f => f.primary) || matchedVer.files[0];
                    requiredDeps.push({
                        projectId: depProjectId,
                        title: proj.title,
                        slug: proj.slug,
                        icon_url: proj.icon_url,
                        projectType: proj.project_type || 'mod',
                        versionId: matchedVer.id,
                        versionName: matchedVer.name,
                        file: {
                            url: primaryFile.url,
                            filename: primaryFile.filename,
                            size: primaryFile.size
                        }
                    });
                }
            }
        }

        try {
            await resolveVersion(versionId, 0);
            res.json({
                hasRequiredDeps: requiredDeps.length > 0,
                requiredDeps,
                skippedDeps
            });
        } catch (e) {
            api.logger.error('[Modrinth Dependencies Resolution Error]', e.message);
            res.status(500).json({ error: e.message });
        }
    });

    // POST /download - Download mod, plugin, or datapack to the instance's directory
    router.post('/download', async (req, res) => {
        const instanceId = (req.body && req.body.instanceId) || api.getActiveInstanceId();
        const instanceDir = api.getInstanceDir(instanceId);
        const { url, filename, type, projectType, projectId, slug, title, versionId } = req.body;
        if (!url || !filename) return res.status(400).json({ error: 'URL and filename required' });

        // 判断目标文件夹：plugins vs mods vs world/datapacks vs resourcepacks
        const actualType = (projectType || type || 'mod').toLowerCase();
        let subDir = 'mods';
        let typeLabel = '模组';
        if (actualType === 'plugin' || actualType === 'plugins') {
            subDir = 'plugins';
            typeLabel = '插件';
        } else if (actualType === 'datapack' || actualType === 'datapacks') {
            subDir = path.join('world', 'datapacks');
            typeLabel = '数据包';
        } else if (actualType === 'resourcepack' || actualType === 'resourcepacks') {
            subDir = 'resourcepacks';
            typeLabel = '资源包';
        }

        const targetFolder = path.join(instanceDir, subDir);
        await fs.ensureDir(targetFolder);
        const dest = path.join(targetFolder, filename);

        api.logger.info(`[资源下载] 正在下载${typeLabel}: ${filename} 到 ${subDir}/ 目录...`);

        try {
            const downloadUrl = applyProxy(url);
            const response = await axios.get(downloadUrl, {
                responseType: 'stream',
                headers: { 'User-Agent': MODRINTH_UA }
            });
            const writer = fs.createWriteStream(dest);
            response.data.pipe(writer);

            writer.on('finish', async () => {
                api.logger.info(`[资源下载] 成功安装 ${filename} 到 ${subDir}/ 目录`);

                // 记录安装入库，便于后续快速识别和依赖判断
                await recordInstalledResource(instanceDir, {
                    projectId,
                    slug,
                    title,
                    filename,
                    versionId,
                    type: actualType
                });

                res.json({ success: true, targetDir: subDir, filename });
            });

            writer.on('error', (err) => {
                api.logger.error('[资源下载] 下载写入失败', err.message);
                res.status(500).json({ error: err.message });
            });
        } catch (e) {
            api.logger.error('[资源下载] 安装过程出错', e.message);
            res.status(500).json({ error: e.message });
        }
    });

    api.registerRoutes('/', router);
    api.registerSidebarItem({
        id: 'modrinth',
        view: 'modrinth-view',
        icon: 'fa-cloud-arrow-down',
        labelKey: 'sidebar.modrinth',
        location: 'instance'
    });
    api.registerComponent('modrinth-view', 'component/MainView.js');

    api.logger.info('[Modrinth Plugin] Backend initialized.');
};
