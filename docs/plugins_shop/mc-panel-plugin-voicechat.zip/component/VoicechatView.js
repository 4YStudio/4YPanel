import { ref, reactive, onMounted, computed, watch, getCurrentInstance } from '/js/vue.esm-browser.js';
import { api } from '/js/api.js';
import { store } from '/js/store.js';
import { showToast } from '/js/utils.js';

export default {
    template: `
    <div class="voicechat-view animate-in">
        <!-- Unsupported on Vanilla Instance -->
        <div v-if="!hasVoicechat && serverStatus.isVanilla" class="d-flex flex-column align-items-center justify-content-center py-5 text-muted text-center animate-in">
            <div class="p-4 rounded-circle bg-warning-subtle text-warning border border-warning-subtle shadow-sm mb-3">
                <i class="fa-solid fa-ban fa-3x"></i>
            </div>
            <h4 class="fw-bold text-body mb-2">当前实例架构不支持语音聊天</h4>
            <p class="text-muted small mb-2 px-3" style="max-width: 560px;">
                当前实例运行在<strong>官方原版 (Vanilla)</strong> 服务端架构上，原生不支持加载任何第三方插件或模组。
            </p>
            <p class="text-muted small mb-4 px-3" style="max-width: 560px;">
                若需使用 Simple Voice Chat 简单语音聊天，请前往【服务器设置】将核心架构切换为 <strong>Paper / Purpur</strong>（插件服）或 <strong>Fabric / NeoForge</strong>（模组服）。
            </p>
            <div class="d-flex gap-2 flex-wrap justify-content-center px-3">
                <button class="btn btn-primary rounded-pill px-4 py-2 fw-bold shadow-sm" @click="goToSettings">
                    <i class="fa-solid fa-gear me-2"></i>前往服务器设置切换架构
                </button>
                <button class="btn btn-outline-secondary rounded-pill px-3 py-2 fw-bold" @click="forceOpenConfig">
                    <i class="fa-solid fa-sliders me-1"></i>强制打开配置
                </button>
            </div>
        </div>

        <!-- Missing Plugin in Plugin Server -->
        <div v-else-if="!hasVoicechat && serverStatus.isPluginServer" class="d-flex flex-column align-items-center justify-content-center py-5 text-muted text-center animate-in">
            <div class="p-4 rounded-circle bg-body-tertiary text-primary border shadow-sm mb-3">
                <i class="fa-solid fa-microphone-slash fa-3x opacity-50"></i>
            </div>
            <h4 class="fw-bold text-body mb-2">未检测到 Simple Voice Chat 插件</h4>
            <p class="text-muted small mb-2 px-3" style="max-width: 560px;">
                当前实例为 <strong>插件服 ({{ (serverStatus.loaderType || 'Paper').toUpperCase() }})</strong>，但未在 <code>plugins/</code> 目录检测到 Simple Voice Chat 插件。
            </p>
            <p class="text-muted small mb-4 px-3" style="max-width: 560px;">
                您可以前往【资源下载】中心一键搜索并安装 Simple Voice Chat 插件，安装后重启服务器即可使用。
            </p>
            <div class="d-flex gap-2 flex-wrap justify-content-center px-3">
                <button class="btn btn-primary rounded-pill px-4 py-2 fw-bold shadow-sm" @click="goToResourceDownload">
                    <i class="fa-solid fa-cloud-arrow-down me-2"></i>前往下载插件
                </button>
                <button class="btn btn-outline-secondary rounded-pill px-3 py-2 fw-bold" @click="loadFile">
                    <i class="fa-solid fa-rotate me-1"></i>重新检测
                </button>
                <button class="btn btn-ghost text-muted rounded-pill px-3 py-2 fw-medium" @click="forceOpenConfig">
                    强制打开配置
                </button>
            </div>
        </div>

        <!-- Missing Mod in Modded Server / Fallback Missing Prompt -->
        <div v-else-if="!hasVoicechat" class="d-flex flex-column align-items-center justify-content-center py-5 text-muted text-center animate-in">
            <div class="p-4 rounded-circle bg-body-tertiary text-primary border shadow-sm mb-3">
                <i class="fa-solid fa-microphone-slash fa-3x opacity-50"></i>
            </div>
            <h4 class="fw-bold text-body mb-2">未检测到 Simple Voice Chat 模组</h4>
            <p class="text-muted small mb-2 px-3" style="max-width: 560px;">
                此功能专为 <b>Simple Voice Chat (简单语音聊天)</b> 设计，但未在服务器目录检测到对应模组文件或配置。
            </p>
            <p class="text-muted small mb-4 px-3" style="max-width: 560px;">
                您可以前往【资源下载】中心搜索并安装它，或强制打开配置界面。
            </p>
            <div class="d-flex gap-2 flex-wrap justify-content-center px-3">
                <button class="btn btn-primary rounded-pill px-4 py-2 fw-bold shadow-sm" @click="goToResourceDownload">
                    <i class="fa-solid fa-cloud-arrow-down me-2"></i>前往下载模组
                </button>
                <button class="btn btn-outline-secondary rounded-pill px-3 py-2 fw-bold" @click="loadFile">
                    <i class="fa-solid fa-rotate me-1"></i>重新检测
                </button>
                <button class="btn btn-ghost text-muted rounded-pill px-3 py-2 fw-medium" @click="forceOpenConfig">
                    强制打开配置
                </button>
            </div>
        </div>

        <!-- Configuration Editor Panel (When Voice Chat is Detected or Force-Opened) -->
        <template v-else>
            <!-- Overhauled Header Banner (Mobile-Optimized) -->
            <div class="card border-0 shadow-sm rounded-4 mb-3 overflow-hidden position-relative animate-in bg-body-tertiary">
                <div class="card-body p-3 p-md-4">
                    <!-- Row 1: Icon, Title, Type Badge & Top-Right Buttons -->
                    <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-2">
                        <div class="d-flex align-items-center gap-2 gap-md-3 min-w-0">
                            <div class="p-2 rounded-3 bg-primary-subtle text-primary border border-primary-subtle d-flex align-items-center justify-content-center flex-shrink-0" style="width: 42px; height: 42px;">
                                <i class="fa-solid fa-microphone-lines fs-5"></i>
                            </div>
                            <div class="min-w-0">
                                <h5 class="fw-bold m-0 d-flex align-items-center gap-2 flex-wrap fs-6 fs-md-5">
                                    <span class="text-truncate">{{ $t('voice.title') || '简单语音配置' }}</span>
                                    <span class="badge rounded-pill px-2 py-0-5 small fw-semibold border"
                                          :class="serverCategoryBadgeClass" style="font-size: 0.7rem;">
                                        {{ serverCategoryBadgeText }}
                                    </span>
                                </h5>
                            </div>
                        </div>

                        <!-- Top-Right Actions (Responsive Capsule Buttons) -->
                        <div class="d-flex align-items-center gap-2 flex-shrink-0">
                            <button class="btn btn-sm btn-outline-secondary rounded-pill px-3 fw-bold" @click="toggleEditMode">
                                <i class="fa-solid me-1" :class="editMode === 'gui' ? 'fa-code' : 'fa-sliders'"></i>
                                <span>{{ editMode === 'gui' ? ($t('common.mode_text') || '文本模式') : ($t('common.mode_gui') || '图形模式') }}</span>
                            </button>
                            <button class="btn btn-sm btn-success rounded-pill px-3 fw-bold shadow-sm" @click="saveConfig" :disabled="saving">
                                <span v-if="saving" class="spinner-border spinner-border-sm me-1"></span>
                                <i v-else class="fa-solid fa-save me-1"></i>
                                <span>{{ saving ? ($t('common.saving') || '保存中...') : ($t('common.save') || '保存配置') }}</span>
                            </button>
                        </div>
                    </div>

                    <!-- Row 2: File Path & Status Badges (Smooth Wrap, Never Cut Off) -->
                    <div class="d-flex align-items-center gap-2 flex-wrap pt-2 border-top border-secondary border-opacity-10 text-muted small" style="font-size: 0.78rem;">
                        <div class="d-flex align-items-center gap-1 min-w-0">
                            <i class="fa-regular fa-file-code text-primary opacity-75"></i>
                            <span class="font-monospace text-truncate text-body-secondary" style="max-width: 260px;" :title="configFilePath">{{ configFilePath }}</span>
                        </div>
                        <span v-if="!fileExists" class="badge bg-warning-subtle text-warning border border-warning-subtle rounded-pill">
                            {{ $t('voice.template_notice') || '已自动提供默认配置' }}
                        </span>
                        <span v-else class="badge bg-success-subtle text-success border border-success-subtle rounded-pill">
                            已加载实体文件
                        </span>
                        <span class="opacity-50 d-none d-sm-inline">•</span>
                        <span class="text-secondary opacity-75 d-none d-sm-inline">{{ $t('voice.restart_required') || '保存后需重启服务器生效' }}</span>
                    </div>
                </div>
            </div>

            <!-- Editor Body Transition -->
            <Transition name="fade" mode="out-in">
                <!-- GUI Mode Editor -->
                <div v-if="editMode === 'gui'" class="row g-3 pb-4" key="gui">
                    <div class="col-12 col-lg-6" v-for="(group, idx) in vcGroups" :key="idx">
                        <div class="card h-100 border rounded-4 shadow-sm" style="background-color: var(--c-surface) !important;">
                            <div class="card-header bg-body-tertiary fw-bold border-bottom d-flex align-items-center py-2.5 px-3">
                                <i :class="group.icon" class="me-2 text-primary"></i>
                                <span>{{ group.title }}</span>
                            </div>
                            <div class="card-body p-3">
                                <div v-for="item in group.items" :key="item.key" class="mb-3 row align-items-center">
                                    <label class="col-12 col-sm-5 col-form-label small fw-semibold text-body-secondary mb-1 mb-sm-0">{{ item.label }}</label>
                                    <div class="col-12 col-sm-7">
                                        <div v-if="item.type === 'boolean'" class="form-check form-switch m-0 pt-1">
                                            <input class="form-check-input" type="checkbox" v-model="formModel[item.key]">
                                        </div>
                                        <CustomSelect v-else-if="item.type === 'select'" v-model="formModel[item.key]" :options="item.options" size="sm" />
                                        <input v-else :type="item.type" class="form-control form-control-sm rounded-3" v-model="formModel[item.key]" :placeholder="item.placeholder || ''">
                                        <div v-if="item.desc" class="form-text text-muted small mt-1" style="font-size: 0.72rem; line-height: 1.25;">{{ item.desc }}</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-12">
                        <div class="alert alert-info py-2-5 px-3 rounded-3 d-flex align-items-center mb-0 border shadow-sm">
                            <i class="fa-solid fa-circle-info me-2 fs-5 flex-shrink-0 text-info"></i>
                            <div class="small">{{ $t('voice.restart_required') || '修改语音通信端口或主机参数后，请重启 Minecraft 服务器以生效配置。' }}</div>
                        </div>
                    </div>
                </div>

                <!-- Text / Raw Mode Editor -->
                <div v-else class="h-100 pb-3" key="text">
                    <div class="card h-100 shadow-sm border rounded-4 overflow-hidden" style="background-color: var(--c-surface) !important;">
                        <div class="card-header bg-body-tertiary small text-muted border-bottom d-flex justify-content-between align-items-center py-2 px-3">
                            <span class="text-truncate"><i class="fa-regular fa-file-lines me-2"></i>{{ configFilePath }}</span>
                            <span class="badge bg-secondary-subtle text-secondary rounded-pill">{{ lineCount }} 行</span>
                        </div>
                        <textarea class="form-control border-0 rounded-0 h-100 p-3"  
                            style="font-family: var(--font-monospace, monospace); resize: none; min-height: 65vh; background: transparent; color: inherit; line-height: 1.5; font-size: 0.88rem;" 
                            v-model="fileContent" 
                            spellcheck="false"
                        ></textarea>
                    </div>
                </div>
            </Transition>
        </template>
    </div>
    `,
    setup() {
        const editMode = ref('gui');
        const fileContent = ref('');
        const configFilePath = ref('config/voicechat/voicechat-server.properties');
        const fileExists = ref(true);
        const isInstalled = ref(false);
        const forceOpen = ref(false);
        const saving = ref(false);
        const serverStatus = reactive({
            isVanilla: false,
            isPluginServer: false,
            isModServer: false,
            loaderType: ''
        });

        const formModel = reactive({});
        const { proxy } = getCurrentInstance();
        const $t = proxy.$t;

        const hasVoicechat = computed(() => {
            if (forceOpen.value) return true;
            return isInstalled.value;
        });

        const serverCategoryBadgeText = computed(() => {
            if (serverStatus.isPluginServer) return '插件版 (Plugin)';
            if (serverStatus.isModServer) return '模组版 (Mod)';
            if (serverStatus.isVanilla) return '原版 (Vanilla)';
            return '通用配置';
        });

        const serverCategoryBadgeClass = computed(() => {
            if (serverStatus.isPluginServer) return 'bg-info-subtle text-info border-info-subtle';
            if (serverStatus.isModServer) return 'bg-success-subtle text-success border-success-subtle';
            if (serverStatus.isVanilla) return 'bg-warning-subtle text-warning border-warning-subtle';
            return 'bg-secondary-subtle text-secondary border-secondary-subtle';
        });

        const lineCount = computed(() => {
            return fileContent.value ? fileContent.value.split('\n').length : 0;
        });

        const forceOpenConfig = () => {
            forceOpen.value = true;
        };

        const goToSettings = () => {
            store.view = 'properties';
        };

        const goToResourceDownload = () => {
            store.view = 'modrinth';
        };

        const vcGroups = computed(() => [
            {
                title: $t('voice.network') || '网络与连接',
                icon: 'fa-solid fa-network-wired',
                items: [
                    { key: 'port', label: $t('voice.port') || '端口', type: 'number', desc: $t('voice.port_desc') || '语音传输 UDP 端口 (默认 24454)', placeholder: '24454' },
                    { key: 'voice_host', label: $t('voice.host') || '语音主机 (voice_host)', type: 'text', desc: $t('voice.host_desc') || '客户端连接的外部 IP 或域名，留空使用服务器 IP', placeholder: 'example.com:24454' },
                    { key: 'bind_address', label: $t('voice.bind_address') || '绑定地址', type: 'text', desc: $t('voice.bind_address_desc') || '监听网络接口，默认 * 绑定所有地址', placeholder: '* 或留空' },
                    { key: 'allow_pings', label: $t('voice.allow_pings') || '允许 Ping 测试', type: 'boolean', desc: $t('voice.allow_pings_desc') || '允许客户端测试语音服务器延迟' }
                ]
            },
            {
                title: $t('voice.quality_distance') || '语音质量与距离',
                icon: 'fa-solid fa-sliders',
                items: [
                    { key: 'max_voice_distance', label: $t('voice.max_distance') || '最大语音距离', type: 'number', desc: $t('voice.max_distance_desc') || '玩家最大可听到语音的距离方块数 (默认 48.0)', placeholder: '48.0' },
                    { key: 'whisper_distance', label: $t('voice.whisper_distance') || '耳语距离', type: 'number', desc: $t('voice.whisper_distance_desc') || '耳语模式下的最大距离 (默认 24.0)', placeholder: '24.0' },
                    { key: 'broadcast_range', label: $t('voice.broadcast_range') || '广播范围', type: 'number', desc: $t('voice.broadcast_range_desc') || '广播语音范围，-1 为无限', placeholder: '-1.0' },
                    { key: 'codec', label: $t('voice.codec') || '音频编码', type: 'select', options: ['VOIP', 'AUDIO', 'RESTRICTED_LOWDELAY'], desc: $t('voice.codec_desc') || '音频编码类型 (推荐 VOIP)' },
                    { key: 'mtu_size', label: $t('voice.mtu_size') || 'MTU 大小', type: 'number', desc: $t('voice.mtu_size_desc') || '最大传输单元字节大小 (默认 1024)', placeholder: '1024' }
                ]
            },
            {
                title: $t('voice.groups_permissions') || '群组与权限',
                icon: 'fa-solid fa-users-gear',
                items: [
                    { key: 'enable_groups', label: $t('voice.enable_groups') || '启用群组频道', type: 'boolean', desc: $t('voice.enable_groups_desc') || '是否允许玩家创建群组私密语音频道' },
                    { key: 'allow_recording', label: $t('voice.allow_recording') || '允许语音录音', type: 'boolean', desc: $t('voice.allow_recording_desc') || '是否允许客户端录制语音会话' },
                    { key: 'spectator_interaction', label: $t('voice.spectator_interaction') || '旁观者语音互动', type: 'boolean', desc: $t('voice.spectator_interaction_desc') || '是否允许旁观者参与语音交流' },
                    { key: 'spectator_player_possession', label: $t('voice.spectator_player_possession') || '附身旁观者语音', type: 'boolean', desc: $t('voice.spectator_player_possession_desc') || '是否允许附身视角的旁观者使用语音' }
                ]
            },
            {
                title: $t('voice.security_performance') || '安全与性能',
                icon: 'fa-solid fa-shield-halved',
                items: [
                    { key: 'force_voice_chat', label: $t('voice.force_voice_chat') || '强制语音模组', type: 'boolean', desc: $t('voice.force_voice_chat_desc') || '踢出未安装语音聊天客户端的玩家' },
                    { key: 'login_timeout', label: $t('voice.login_timeout') || '登录超时 (ms)', type: 'number', desc: $t('voice.login_timeout_desc') || '语音握手超时时间毫秒数', placeholder: '10000' },
                    { key: 'tcp_rate_limit', label: $t('voice.tcp_rate_limit') || 'TCP 速率限制', type: 'number', desc: $t('voice.tcp_rate_limit_desc') || 'TCP 请求频率限制', placeholder: '16' },
                    { key: 'keep_alive', label: $t('voice.keep_alive') || '保活心跳 (ms)', type: 'number', desc: $t('voice.keep_alive_desc') || '保持连接心跳周期', placeholder: '1000' },
                    { key: 'use_natives', label: $t('voice.use_natives') || '使用原生本地加速库', type: 'boolean', desc: $t('voice.use_natives_desc') || '使用机器底层原生库提升音质与性能' },
                    { key: 'threaded_server_support', label: $t('voice.threaded_server_support') || '多线程服务端支持', type: 'boolean', desc: $t('voice.threaded_server_support_desc') || '兼容多线程核心架构 (如 Folia)' }
                ]
            }
        ]);

        const createRegex = (key) => new RegExp(`^[ \\t]*${key}[ \\t]*=[ \\t]*(.*)$`, 'm');

        const loadFile = async () => {
            try {
                const res = await api.get('/api/voicechat/config');
                fileContent.value = res.data.content || '';
                configFilePath.value = res.data.filePath || 'config/voicechat/voicechat-server.properties';
                fileExists.value = res.data.exists !== false;
                isInstalled.value = Boolean(res.data.hasVoicechat);

                serverStatus.isVanilla = Boolean(res.data.isVanilla);
                serverStatus.isPluginServer = Boolean(res.data.isPluginServer);
                serverStatus.isModServer = Boolean(res.data.isModServer);
                serverStatus.loaderType = res.data.loaderType || '';

                parseToGui();
            } catch (e) {
                console.error('Failed to load voicechat config:', e);
                showToast($t('common.error') + ': ' + (e.response?.data?.error || e.message), 'danger');
            }
        };

        const parseToGui = () => {
            const text = fileContent.value;
            vcGroups.value.forEach(group => {
                group.items.forEach(item => {
                    let match = text.match(createRegex(item.key));
                    if (!match && item.key === 'max_voice_distance') {
                        match = text.match(createRegex('voice_distance'));
                    }
                    if (match) {
                        let valStr = match[1].trim();
                        if (item.type === 'boolean') {
                            formModel[item.key] = (valStr.toLowerCase() === 'true');
                        } else if (item.type === 'number') {
                            formModel[item.key] = valStr === '' ? '' : Number(valStr);
                        } else {
                            formModel[item.key] = valStr;
                        }
                    } else {
                        if (item.type === 'boolean') formModel[item.key] = false;
                        else if (item.key === 'port') formModel[item.key] = 24454;
                        else if (item.key === 'codec') formModel[item.key] = 'VOIP';
                        else formModel[item.key] = '';
                    }
                });
            });
        };

        const syncToText = () => {
            let text = fileContent.value || '';
            vcGroups.value.forEach(group => {
                group.items.forEach(item => {
                    const val = formModel[item.key];
                    if (val !== undefined) {
                        const targetKey = item.key;
                        const valStr = String(val);
                        const mainRegex = createRegex(targetKey);
                        const legacyRegex = (targetKey === 'max_voice_distance') ? createRegex('voice_distance') : null;

                        if (mainRegex.test(text)) {
                            text = text.replace(mainRegex, `${targetKey}=${valStr}`);
                        } else if (legacyRegex && legacyRegex.test(text)) {
                            text = text.replace(legacyRegex, `${targetKey}=${valStr}`);
                        } else {
                            if (text && !text.endsWith('\n')) text += '\n';
                            text += `${targetKey}=${valStr}\n`;
                        }
                    }
                });
            });
            fileContent.value = text;
        };

        const saveConfig = async () => {
            if (editMode.value === 'gui') syncToText();
            try {
                saving.value = true;
                await api.post('/api/voicechat/save', {
                    content: fileContent.value,
                    filePath: configFilePath.value
                });
                fileExists.value = true;
                showToast($t('voice.saved') || '语音聊天配置文件已成功保存！');
            } catch (e) {
                showToast($t('common.error') + ': ' + (e.response?.data?.error || e.message), 'danger');
            } finally {
                saving.value = false;
            }
        };

        const toggleEditMode = () => {
            if (editMode.value === 'text') {
                parseToGui();
                editMode.value = 'gui';
            } else {
                syncToText();
                editMode.value = 'text';
            }
        };

        // 监听实例切换
        watch(() => store.currentInstanceId, () => {
            forceOpen.value = false;
            loadFile();
        });

        onMounted(() => {
            loadFile();
        });

        return {
            store,
            hasVoicechat,
            serverStatus,
            serverCategoryBadgeText,
            serverCategoryBadgeClass,
            editMode,
            fileContent,
            configFilePath,
            fileExists,
            saving,
            formModel,
            vcGroups,
            lineCount,
            forceOpenConfig,
            goToSettings,
            goToResourceDownload,
            loadFile,
            saveConfig,
            toggleEditMode
        };
    }
};
